import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Customers from './pages/Customers'
import Riders from './pages/Riders'
import Analytics from './pages/Analytics'
import Payments from './pages/Payments'
import Orders from './pages/Orders'
import './App.css'

function App() {
  return (
    <BrowserRouter>
      <div className="app">
        <aside className="sidebar">
          <div className="logo">
            <span className="logo-mark">B</span>
            <span>BUZZ</span>
          </div>

          <nav>
 	 <Link to="/" className="active">Dashboard</Link>
 	 <Link to="/orders">Orders</Link>
 	 <Link to="/riders">Riders</Link>
	 <Link to="/customers">Customers</Link>
         <Link to="/payments">Payments</Link>
         <Link to="/analytics">Analytics</Link>

          </nav>

          <div className="sidebar-bottom">
            <a>Settings</a>
            <a>Logout</a>
          </div>
        </aside>

        <main className="main">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/orders" element={<Orders />} />
	<Route path="/riders" element={<Riders />} />
              <Route path="/customers" element={<Customers />} /> 
            <Route path="/payments" element={<Payments />} />
            <Route path="/analytics" element={<Analytics />} />


          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

export default App
